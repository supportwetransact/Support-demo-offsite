# WeTransact Help Center

A branded doc hub for WeTransact help articles, in the spirit of Archbee: browse collections, search, and write / draft / publish articles in Markdown.

- `index.html` — the full app (vanilla JS, no build step). Markdown via marked + DOMPurify from cdnjs.
- `fonts/` — Greycliff CF (brand typeface).
- `img/` — Octavia mascot illustrations.
- `seed/` — starter collections and articles (JSON).

## Data model
| Collection | Purpose | Who can read |
| --- | --- | --- |
| `sections` | Collections (name, description, icon, order) | Everyone |
| `drafts` | Working copy of every article (autosaved) | Editors only |
| `articles` | Published copy readers see | Everyone |

Publishing copies a draft into `articles`; unpublishing deletes it from `articles`.

Live version is hosted as a Claude artifact with shared storage. To self-host, replace the `claude.use("db")` calls with your own backend (e.g. Firestore — the API shape is Firestore-like).
